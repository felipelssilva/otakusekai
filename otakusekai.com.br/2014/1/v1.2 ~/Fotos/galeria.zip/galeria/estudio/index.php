<?
echo "<title>403</title> <h1>Forbidden</h1> You were denied access because: <br/><br/> Access denied by access control to this page. <br /> <hr> Your IP address is saved: ".$_SERVER['REMOTE_ADDR']."";
?>