<h1><strong>Complete Poked&eacute;x!</strong></h1>

<p>&nbsp;</p>
<div style="float:right; margin:15px;"><p style="text-align: justify;"><img src="Fotos/PROFESSORSYCAMORE.png" width="200" height="314" />
</p></div>
<p style="text-align: justify;">
	Prazer em conhec&ecirc;-los, meu nome &eacute; professor Sycamore, bem vindos ao mundo Pok&eacute;mon!</p>
		<p style="text-align: justify;">
			No nosso mundo existem criaturas chamadas Pocket Monsters, tamb&eacute;m conhecidas como Pok&eacute;mon. N&oacute;s criamos Pok&eacute;mons como animais de estima&ccedil;&atilde;o, ou criamos eles para lutarem...</p>
<p style="text-align: justify;">
			Convivemos com eles de v&aacute;rias formas! Preparados para o mundo Pok&eacute;mon? Ent&atilde;o vou gui&aacute;-los por um mundo de sonho e aventura!</p>
		

		<p style="text-align: justify;">
			Os melhores treinadores Pok&eacute;mons s&atilde;o aqueles que possuem o maior conhecimento sobre eles! Pra registrar isso temos a poked&eacute;x, que &eacute; entregue a cada iniciante para come&ccedil;ar sua jornada. A C.A.O.S. est&aacute; cheia de Pok&eacute;bolas secretas escondidas por a&iacute; e sua miss&atilde;o para mostrar que &eacute; o melhor mestre Pok&eacute;mon &eacute; encontr&aacute;-las! Cada Pok&eacute;bola possui um pr&ecirc;mio e um Pok&eacute;mon e no final, aquele que tiver o maior n&uacute;mero de Pok&eacute;mons capturados vai levar um super pr&ecirc;mio!!!&nbsp;</p>
<p style="text-align: justify;">
			Se houver empate entre algum treinador, ser&aacute; resolvido com um quis Pok&eacute;mon. BOA SORTE!</p>

		<p>&nbsp;</p>
		<p style="text-align: center;"><img src="Fotos/POKEDEX.jpg" width="493" height="407" /></p>
