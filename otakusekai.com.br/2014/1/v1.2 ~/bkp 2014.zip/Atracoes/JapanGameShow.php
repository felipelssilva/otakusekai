<h1><strong>JAPAN GAME SHOW</strong></h1>

<p style="text-align: justify;">
				A C.A.O.S. vai ser palco de um reality show que promete tirar gargalhadas do p&uacute;blico, s&oacute; que pra isso acontecer quem v&atilde;o sofrer s&atilde;o os participantes! Baseado nos games shows japon&ecirc;s, adaptado pra algo menos insano um pouco, haver&aacute; duas equipes, disputando para sobreviver aos nossos jogos onde tudo pode acontecer! Torta na cara, bal&atilde;o de farinha, balde de &aacute;gua e &eacute; claro, para valer a pena uma premia&ccedil;&atilde;o bem legal! Aguardem!</p>
<p>&nbsp;</p>
<p><img src="Fotos/gameshow.jpg" width="385" height="225"></p>
