<h1><strong>PALESTRA COM ISABEL DE S&Aacute; E M&Aacute;RCIO ARA&Uacute;JO</strong></h1>

			<p style="text-align: justify;">&nbsp;
				</p>
			<p style="text-align: justify; margin-left: 40px;">
				&quot;Preparem-se para a encrenca!<br />
				Encrenca em dobro!<br />
				Para proteger o mundo da devasta&ccedil;&atilde;o!<br />
				Para unir as pessoas de nossa na&ccedil;&atilde;o!<br />
				Para denunciar os males da verdade e do amor!<br />
				Para estender o nosso poder as estrelas!<br />
				Jessie!<br />
				James!<br />
				Equipe Rocket decolando na velocidade da luz!<br />
				Rendam-se agora ou preparem-se para lutar!&quot;</p>
			<p style="text-align: justify;">
				Essa super dupla vai falar sobre dublagem, sobre sua carreira, esclarecer todas as duvidas, reviver os momentos marcantes al&eacute;m da sess&atilde;o de aut&oacute;grafos e muito mais!</p>
			<p style="text-align: justify;">&nbsp;
				</p>
                
                <div style="float:right; padding:20px; margin-top:100px;"><img src="Fotos/Dubladores.jpg" width="350" /></div>
                
<p style="text-align: justify;">
				<strong>Isabel de S&aacute;: </strong></p>
			<p style="text-align: justify; margin-left: 40px;">
				Jessie em Pok&eacute;mon;<br />
				Senhora Briefs (M&atilde;e da Bulma) em Dragon Ball;<br />
				Lita (Sailor J&uacute;piter) em Sailor Moon (Vers&atilde;o Gota M&aacute;gica);<br />
				Marin de &Aacute;guia em Os Cavaleiros do Zod&iacute;aco (redublagem);<br />
				Mai Valentine em Yu-Gi-Oh!;<br />
				Lux em Saber Marionette J;<br />
				Tatra em Guerreiras M&aacute;gicas de Rayearth;<br />
				Seika - Cavaleiros do Zod&iacute;aco;<br />
				Carta Luz - Sakura Card Captors;<br />
				Tsume Inuzuka - Naruto;<br />
				Lita (Makoto Kino) - Sailor Moon (pelo est&uacute;dio Gota M&aacute;gica);<br />
				M&atilde;e do Tsubasa (Super Campe&otilde;es J primeira fase) - Captain Tsubasa;<br />
				Velhinha que joga &aacute;gua - Ranma &frac12;;<br />
				Dra. Inga Agridoce - Totally Spies! (Tr&ecirc;s Espi&atilde;s Demais);<br />
				Rey Von Chrimson- Grand Chase ( Jogo da K.O.G&#39; administrado pela Level Up! Games no Brazil).</p>
			<p style="text-align: justify;">&nbsp;
				</p>
			<p style="text-align: justify;">
				<strong>M&aacute;rcio Ara&uacute;jo: </strong></p>
			<p style="text-align: justify; margin-left: 40px;">
				James (Jessie &amp; James) em Pok&eacute;mon;<br />
				Shino Aburame em Naruto;<br />
				Milo de Escorpi&atilde;o em Os Cavaleiros do Zod&iacute;aco;<br />
				Yamcha em Dragon Ball;<br />
				Oliver Tsubasa em Super Campe&otilde;es;<br />
				Mamiya Otaru em Saber Marionette;<br />
				Koji Minamoto em Digimon Fontier (ou Digimon IV);<br />
				Donatello em As Tartarugas Mutantes Ninja;<br />
				Martin Kratt em Zuboomafoo;<br />
				Ranma Saotome em Ranma &frac12;.</p>