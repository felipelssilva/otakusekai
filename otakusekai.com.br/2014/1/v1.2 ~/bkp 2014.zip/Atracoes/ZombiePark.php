<h1><strong>ZOMBIE PARK</strong></h1>

<p style="text-align: justify;">
				Seguindo a tradi&ccedil;&atilde;o da CAOS, aqui voc&ecirc; cumprir uma miss&atilde;o de resolver o enigma para escapar daqui vivo, mas as coisas n&atilde;o s&atilde;o t&atilde;o f&aacute;ceis, tem zombies espalhados pra todo lado tentando te impedir! Voc&ecirc;s v&atilde;o conseguir sobreviver ao horror? Conseguir&aacute; completar sua miss&atilde;o sem se tornar um deles? Boa sorte!</p>
			<p style="text-align: justify;">
				Esse ano com uma surpresa!</p>
                
<p>&nbsp;</p>
<p><img src="Fotos/zombiepark.jpg" width="700" /></p>
