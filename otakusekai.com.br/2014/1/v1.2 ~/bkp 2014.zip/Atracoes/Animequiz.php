<h1><strong>Animequiz</strong></h1>


<div align="center">
	<img src="Fotos/animequiz.jpg" width="480" height="360" />
</div>


<p style="text-align: justify;">
Chegou &agrave; hora de testar seus conhecimentos sobre os Anime, Mang&aacute;, Tokusatsu, Comics entre outros! Venha para o palco encarar esse super desafios e ganhar pr&ecirc;mios!</p>
			<p style="text-align: justify;">&nbsp;
</p>
			<p style="text-align: justify;">
				<strong>1.</strong> <strong>Informa&ccedil;&otilde;es Gerais</strong></p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>1.1</strong> &ndash; O Anime Quiz aconteceram no palco.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>1.2</strong> &ndash; A Participa&ccedil;&atilde;o nesta modalidade de Quiz ser&aacute; realizada em trios.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>1.3</strong> &ndash; A competi&ccedil;&atilde;o se dar&aacute; entre, no m&aacute;ximo, 8 (oito) equipes inscritas.</p>
			<p style="text-align: justify; margin-left: 40px;">&nbsp;
</p>
			<p style="text-align: justify;">
				<strong>2.</strong> <strong>Inscri&ccedil;&atilde;o</strong></p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>2.1</strong> &ndash; As inscri&ccedil;&otilde;es do Anime Quiz come&ccedil;am &agrave;s 10h00 e ser&atilde;o finalizadas com meia hora de anteced&ecirc;ncia do concurso no palco.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>2.2</strong> &ndash; Ser&atilde;o apenas 08 (oito) vagas para as equipes. Os trios que se inscreverem ap&oacute;s preenchimento de todas as vagas, ficar&atilde;o em lista de espera, caso o grupo n&atilde;o compare&ccedil;a no momento do campeonato.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>2.3</strong> &ndash; A equipe tem o direito de inscrever 1 (um) substituto, que s&oacute; participar&aacute; do campeonato na falta de algum membro. O substituto n&atilde;o pode ser modificado ap&oacute;s a inscri&ccedil;&atilde;o, e n&atilde;o poder&aacute; estar inscrito em nenhum outro grupo.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>2.4</strong> &ndash; No ato da inscri&ccedil;&atilde;o o trio deve estar presente para preencher as fichas de inscri&ccedil;&atilde;o.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>2.5</strong> &ndash; Cada equipe deve escolher um nome, que n&atilde;o pode ser ofensivo, nem conter palavr&otilde;es ou palavras inapropriadas.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>2.6</strong> &ndash; A inscri&ccedil;&atilde;o do Anime Quiz &eacute; gratuita.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>2.7</strong> &ndash; A equipe deve ser composta por no m&aacute;ximo tr&ecirc;s componentes, contudo, &eacute; poss&iacute;vel se inscrever no Anime Quis em dupla ou individualmente.</p>
			<p style="text-align: justify;">&nbsp;
</p>
			<p style="text-align: justify;">
				<strong>3.</strong> <strong>Da Prepara&ccedil;&atilde;o</strong></p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>3.1 &ndash;</strong> Os trios devem comparecer na sala do evento com meia hora de anteced&ecirc;ncia do concurso, para as &uacute;ltimas instru&ccedil;&otilde;es. O atraso acarretar&aacute; em desclassifica&ccedil;&atilde;o.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>3.2 &ndash;</strong> &Eacute; necess&aacute;rio que a equipe esteja presente, caso um n&atilde;o esteja presente, pode-se solicitar o substituto que foi previamente inscrito. Caso o substituto tamb&eacute;m n&atilde;o esteja presente, o participante concorrer&aacute; sozinho no Quiz.</p>
			<p style="text-align: justify;">&nbsp;
</p>
			<p style="text-align: justify;">
				<strong>4.</strong> <strong>Da Rodada de Perguntas</strong></p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>4.1 &ndash;</strong> Cada equipe enfrentar&aacute; outra equipe em uma rodada de perguntas, podendo conter questionamentos com ou sem alternativas, nome do personagem atrav&eacute;s de foto ou qualquer tipo de pergunta em rela&ccedil;&atilde;o ao anime.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>4.2 &ndash;</strong> Cada rodada conter&aacute; at&eacute; tr&ecirc;s turnos, sendo que no primeiro turno ser&aacute; exibida uma lista contendo tr&ecirc;s animes aleat&oacute;rios para cada equipe, o qual o trio escolher&aacute; um destes para responder tr&ecirc;s perguntas, no segundo turno ser&aacute; exibido novamente outra lista contendo tr&ecirc;s animes aleat&oacute;rios onde escolheram o anime para a equipe advers&aacute;ria responder. Caso haja empate, no terceiro turno, o julgador far&aacute; perguntas aleat&oacute;rias de qualquer anime para cada equipe, at&eacute; que haja um vencedor.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>4.3 &ndash;</strong> As chaves ser&atilde;o formadas aleatoriamente ap&oacute;s a inscri&ccedil;&atilde;o das duplas.</p>
			<p style="text-align: justify;">&nbsp;
</p>
			<p style="text-align: justify;">
				<strong>5.</strong> <strong>Proibi&ccedil;&otilde;es</strong></p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>5.1 &ndash;</strong> N&atilde;o &eacute; permitido uso de celular no momento do campeonato, nem de nenhum aparelho eletr&ocirc;nico.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>5.2 &ndash;</strong> A equipe que receber ajuda da plat&eacute;ia ser&aacute; penalizada em uma quest&atilde;o anulada para cada ajuda que receber.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>5.3 &ndash;</strong> Uma equipe n&atilde;o deve atrapalhar outra, podendo ser penalizada em uma quest&atilde;o anulada por isso.</p>
			<p style="text-align: justify;">&nbsp;
</p>
			<p style="text-align: justify;">
				<strong>6.</strong> <strong>Premia&ccedil;&atilde;o</strong></p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>6.1 &ndash;</strong> A premia&ccedil;&atilde;o ser&aacute; entregue no momento em que o Quiz for encerrado.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>6.2 &ndash;</strong> Resultados oficiais ser&atilde;o publicados nas redes sociais e todos meios de divulga&ccedil;&atilde;o que o evento utiliza.</p>
			<p style="text-align: justify; margin-left: 40px;">
				&nbsp;<strong>6.3 &ndash;</strong> O evento reserva-se o direito de publicar fotos e v&iacute;deos da competi&ccedil;&atilde;o em suas publicidades em geral, cartazes, sites, blogs, etc.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>6.4 &ndash;</strong> A premia&ccedil;&atilde;o ser&aacute; simb&oacute;lica, sendo brindes aos melhores colocados.</p>
			<p style="text-align: justify; margin-left: 40px;">
				<strong>6.5 &ndash;</strong> A organiza&ccedil;&atilde;o reserva-se no direito de realizar qualquer mudan&ccedil;a sem pr&eacute;vio aviso.</p>
<p style="text-align: justify;">&nbsp;
</p>
<p style="text-align: justify;">
				<strong>7. Lista de Animes e Mang&aacute;s</strong></p>
<table width="50%" border="0">
  <tr>
    <td width="50%" align="center">Death Note </td>
    <td width="50%" align="center">Beyblade</td>
  </tr>
  <tr>
    <td align="center">Soul Eater</td>
    <td align="center">Durarara!!</td>
  </tr>
  <tr>
    <td align="center">D.Gray Man</td>
    <td align="center">Inazuma Eleven</td>
  </tr>
  <tr>
    <td align="center">Bakuman</td>
    <td align="center">Elfen Lied</td>
  </tr>
  <tr>
    <td align="center">Code Geass</td>
    <td align="center">Yugioh</td>
  </tr>
  <tr>
    <td align="center">Zatch Bell</td>
    <td align="center">Vampire Knight</td>
  </tr>
  <tr>
    <td align="center">Pok&eacute;mon</td>
    <td align="center">FMA</td>
  </tr>
  <tr>
    <td align="center">Digimon</td>
    <td align="center">Katekyo Hitman Reborn</td>
  </tr>
  <tr>
    <td align="center">Naruto</td>
    <td align="center">Hunter X Hunter</td>
  </tr>
  <tr>
    <td align="center">One Piece</td>
    <td align="center">Kuroshitsuji</td>
  </tr>
  <tr>
    <td align="center">Bleach</td>
    <td align="center">Shaman King</td>
  </tr>
  <tr>
    <td align="center">Air Gear</td>
    <td align="center">Accel World</td>
  </tr>
  <tr>
    <td align="center">Dragon Ball</td>
    <td align="center">Kuroko no Basket</td>
  </tr>
  <tr>
    <td align="center">Saint Seiya</td>
    <td align="center">Sword Art Online</td>
  </tr>
  <tr>
    <td align="center">Medabots</td>
    <td align="center">Entre outros&hellip;</td>
  </tr>
</table>