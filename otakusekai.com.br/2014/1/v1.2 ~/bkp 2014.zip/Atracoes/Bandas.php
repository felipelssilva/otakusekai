<h1 style="text-align: justify;">
				<strong>Kyoodai Land</strong></h1>

<p style="text-align: justify;">
			A banda mineira Kyoodai Land surgiu em 2012 e tem como proposta divulgar seu trabalho baseado na cultura pop rock oriental para o p&uacute;blico brasileiro.</p>
		<p style="text-align: justify;">
			A atual forma&ccedil;&atilde;o da banda &eacute; Jennifer Pansani (voz), Jefferson Silva (bateria), Matheus Estev&atilde;o (guitarra solo), Alexandre Wallan (guitarra base) e Lucas Neves (contrabaixo).</p>
		<p style="text-align: justify;">
			Possui um amplo repert&oacute;rio, fazendo covers de bandas proeminentes como Flow, Scandal, Fade e Orange Range e tamb&eacute;m inclue m&uacute;sicas como GO!, Shunkan Sentimental, One Reason e Asterisk.</p>
		<p style="text-align: justify;">
			Al&eacute;m disso tamb&eacute;m tocamos Anime Songs em suas vers&otilde;es originais e traduzidas, como as famosas m&uacute;sicas Chala Head Chala e Sorriso Resplandecente.</p>
            
			<p style="text-align: center;"><img src="Fotos/kyoodai_land.jpg" width="576" height="432" /></p>
			<p style="text-align: justify;">&nbsp;
</p>
			<h1>
				<strong>B-Quatro</strong></h1>
			<p style="text-align: justify;">
				Legitimamente uberabense a B-quatro integra a tradi&ccedil;&atilde;o musical mineira e vem se destacando com o seu pop-rock de qualidade e estilo pr&oacute;prio.</p>
			<p style="text-align: justify;">
				Composta por Marco G&oacute;mez (Vocal), Marcelo Vieira (Guitarra), Rog&eacute;rio (Teclados), Chaene da Gama (Baixo) e Rodrigo Augusto (Bateria), vem impriminado a sua marca no cen&aacute;rio sudeste desde de 2000.</p>
			<p style="text-align: justify;">
				Durante estes 13 anos de exist&ecirc;ncia, J&aacute; dividiu palco com grandes nomes da m&uacute;sica popular brasileira, tais como Capital Inicial, Tihuana, Mr Gym e Wilson Sideral, sendo tamb&eacute;m destaque no Concurso de Bandas &quot;Tri&acirc;ngulo Music&quot;, um dos maiores festivais de bandas do Brasil, evento realizado pela rede Integra&ccedil;&atilde;o de TV e CTBC, conseguindo se figurar entre as tr&ecirc;s melhores bandas independentes de toda Minas Gerais, destaque tambem no concurso de bandas &quot;Jo&atilde;o Rock 2013&quot; um concurso com 530 bandas inscritas do Brasil inteiro se figurando entre as 3 mais votadas.</p>
			<p style="text-align: justify;">
				Acostumada com grandes eventos, J&aacute; fez show pra mais de 15 mil pessoas, al&eacute;m de ser bastante conhecia do p&uacute;blico Uberabense, sempre tem presen&ccedil;a <br />
marcada em todas as grandes casas de shows da cidade e da regi&atilde;o.</p>
<p style="text-align: justify;">
  <a href="http://www.bquatro.com/" target="_blank">http://www.bquatro.com/</a></p>
			<p style="text-align: center;">
<img src="Fotos/b-quatro.jpg" width="651" height="203" /></p>
			<p style="text-align: justify;">&nbsp;</p>
			<h1 style="text-align: justify;">THEORIA</h1>
			<p style="text-align: justify;">&nbsp;</p>
			<p style="text-align: justify;">EM BREVE</p>
<p style="text-align: justify;">&nbsp;</p>
<p style="text-align: center;"><img src="Fotos/THEORIA.jpg" width="480" height="339" /></p>
<p style="text-align: justify;">&nbsp;</p>
			<p style="text-align: justify;">
				Mais atualiza&ccedil;&otilde;es em breve.</p>