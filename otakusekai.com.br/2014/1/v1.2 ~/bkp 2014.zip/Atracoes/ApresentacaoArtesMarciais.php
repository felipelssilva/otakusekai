<h1><strong>APRESENTA&Ccedil;&Atilde;O DE ARTES MARCIAIS</strong></h1>

<p style="text-align: justify;">&nbsp;</p>
<p style="text-align: center;"><img src="Fotos/AMKFU.jpg" width="438" height="480" /></p>
<p style="text-align: justify;">&nbsp;</p>
		<p style="text-align: justify;">
			Teremos uma maiores escolas de Uberaba de Kung-Fu:</p>
		<p style="text-align: justify;">
			Kung Fu significa Trabalhar Duro, e &eacute; uma palavra chinesa para denominar um tipo de arte marcial. Para os chineses, kung fu n&atilde;o &eacute; usado apenas para a luta, significa algo que foi adquirido com muito esfor&ccedil;o e compet&ecirc;ncia na luta corporal.</p>
		<p style="text-align: justify;">
			O kung fu tem origem na necessidade dos chineses, h&aacute; muito tempo atr&aacute;s, lutarem contra animais ferozes e inimigos. Existem diversas lendas sobre a verdadeira origem, mas um monge chin&ecirc;s chamado Ta Mo, subiu numa montanha e come&ccedil;ou a observar o movimento dos animais, as posi&ccedil;&otilde;es que lutavam e tamb&eacute;m como se defendiam. A partir dessa observa&ccedil;&atilde;o surgiu o kung fu, que para os orientais &eacute; considerado uma arte, e n&atilde;o uma luta.</p>
		<p style="text-align: justify;">
			O termo kung fu se popularizou no final dos anos 60, pela repercuss&atilde;o dos filmes de artes marciais, estrelados por atores como Bruce Lee e Jackie Chan, al&eacute;m dos seriados na televis&atilde;o. O kung fu tem o objetivo de trabalhar n&atilde;o apenas o corpo, mas tamb&eacute;m o desenvolvimento pessoal, criando disciplina, persist&ecirc;ncia e respeito aos limites dos indiv&iacute;duos; ele estrutura o corpo e a mente fazendo com que as pessoas aprendam a serem derrotas, e poder encarar novos obst&aacute;culos sem desistir ou desanimar.</p>
		<p style="text-align: justify;">
			O kung fu foi reformulado, existe o kung fu moderno, que &eacute; mais voltado para atletas, que est&atilde;o mais preocupados com o corpo, e o kung fu tradicional, que possui toda a filosofia chinesa, e pode ser praticado por pessoas de todas as idades.</p>