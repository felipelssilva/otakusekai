    <!-- conteudos -->
		

<div id="NoticiasConteudo">
        <h1><strong>PREPARADOS?</strong></h1>      
    <div style="margin-left:40px;">
      <p style="text-align: justify;">
			J&Aacute; PREPARARAM SEUS COSPLAYS? FALTAM APENAS 2 SEMANAS PARA O EVENTO!!<br />
			<br />
			C.A.O.S. SPECIAL EDITION 2014<br />
			N&Atilde;O PERCAM DIA 1&deg; DE JUNHO NA SAMBUR&Aacute;!</p>
            
			<br />
            <img src="Fotos/988864_689253857808088_6725637621883330390_n.jpg" width="270" height="360" /><br />
           </p>
    </div>
</div>

<div id="NoticiasConteudo">
        <h1><strong>CAMISA OTAKU SEKAI</strong></h1>      
    <div style="margin-left:40px;">
      <p style="text-align: justify;">
			JESSICA LOPES OLIVEIRA J&Aacute; TIROU SUA FOTO COM SEU INGRESSO E EST&Aacute; CONCORRENDO &Agrave; UMA CAMISETA DO EVENTO!!!<br />
			CORRA E ADQUIRA J&Aacute; SEU INGRESSO, TIRE SUA FOTO E PARTICIPE VOC&Ecirc; TAMB&Eacute;M!!!<br />
			<br />
			C.A.O.S. SPECIAL EDITION 2014<br />
	  N&Atilde;O PERCAM DIA 1&deg; DE JUNHO NA SAMBUR&Aacute;!</p>
            
			<br />
            <img src="Fotos/10313061_688337171233090_4782683022927302108_n.jpg" width="270" height="360" /><br />
           </p>
    </div>
</div>

<div id="NoticiasConteudo">
        <h1><strong>CARTAZ</strong></h1>
            
    <div style="margin-left:40px;">
           <p>SE&nbsp;VER ESSE CARTAZ PARE E COMPRE!<br />
			<br />
			C.A.O.S. SPECIAL EDITION 2014<br />
			N&Atilde;O PERCAM DIA 1&deg; DE JUNHO NA SAMBUR&Aacute;!<br />
			<br />
            <a href="?p=Ingressos"><img src="Fotos/cartazotaku.jpg" width="372" height="480" /></a><br />
           </p>
    </div>
</div>

<div id="NoticiasConteudo">
        <h1><strong>Mineira Sem Freio</strong></h1>
            
    <div style="margin-left:40px;">
           <p>
			PESSOAL, DEMOS AS CARAS NO NOSSO BLOG PREFERIDO O MINEIRA SEM FREIO! <br />
			<br />
			VALE A PENA CONFERIR A MAT&Eacute;RIA:&nbsp;<br />
			<br />
			<a href="http://www.mineirasemfreio.com.br/2014/05/edicao-2014-da-convencao-anime-otaku.html" rel="nofollow nofollow" target="_blank">http://www.mineirasemfreio.com.br/2014/05/edicao-2014-da-convencao-anime-otaku.html</a><br />
			<br />
			<img src="Fotos/WP_20140507_014.jpg" width="480" height="269" /><br />
      </p>
    </div>
</div>

<div id="NoticiasConteudo">
        <h1><strong>Otaku Sekai</strong></h1>
            
    <div style="margin-left:40px;">
<p>
			ISABEL DE S&Aacute;, M&Aacute;RCIO ARA&Uacute;JO, CAMPEONATOS DE NARUTO NINJA STORM 3, INUSTICE, DRAGON BALL BUDOKAI TENKAICHI 3, SUPER SMASH BROS, PES 2014 EM CLIMA DE COPA, BANDAS KYODAI LAND, B4, THEORIA, CONCURSO DE COSPLAY E MUITO MAIS T&Aacute; CHEGANDO, S&Oacute; NA C.A.O.S. SPECIAL EDITION! <br />
			<br />
	CORRA PARA OS PONTOS DE VENDA, NANDA FASHION NA RUI BARBOSA OU YOGOBERRY NO SHOPPING UBERABA E ADQUIRA J&Aacute; O SEU POR R$15,00 E VOC&Ecirc; AINDA CONCORRE A UMA CAMISA DO EVENTO SE TIRAR A MELHOR FOTO COM ELE!!!<br />
			<br />
			<br />
<br />
<img src="Fotos/1175336_682980891768718_7003145597774345982_n.jpg" width="576" height="350" /></p>
    </div>
</div>

<div id="NoticiasConteudo">
        <h1><strong>PONTOS DE VENDA</strong></h1>
            
    <div style="margin-left:40px;">
<p>
			E OS PONTOS DE VENDA S&Atilde;O... YOGOBERRY NO SHOPPING UBERABA E NANDA FASHION NA RUI BARBOSA!!!<br />
			&nbsp;<br />
			ADQUIRA J&Aacute; SEU INGRESSO ANTECIPADO DA CAOS SPECIAL EDITION 2014! <br />
			<br />
	E J&Aacute; SABEM N&Eacute;? QUEM TIRAR A FOTO MAIS MANEIRA COM OS CONVITES GANHA CAMISETA DO EVENTO!<br />
	<br />
	<img src="Fotos/pontosdevenda.png" width="646" height="436" /></p>

    </div>
</div>

    <!-- conteudos -->
