<div id="blocoDestaques" align="left"> <a class="faixa" href="#" title="">
        <!-- -->
        </a>
        <ul>
          <li> <a href="?p=Atracoes&acao=Atracoes%2FIsabeldeSaeMarcioAraujo">
            <div id="img"> <img src="Fotos/bDubladores.jpg" name="i" width="450" height="400" id="i" /> </div>
            
          <div class="fundo">
              <p> <strong>Palestra com Isabel de S&aacute; e M&aacute;rcio Ara&uacute;jo</strong></p>
   			<p><small>Os dubladores de Jessie e James em uma intera&ccedil;&atilde;o com a galera com bate-papo sobre dublagem e suas carreiras, com din&acirc;micas e performances incr&iacute;veis!</small></p>
            </div>
            </a>
          </li>
          
<li> <a href="?p=Atracoes&acao=Atracoes%2FBandas">
            <div id="img"> <img src="Fotos/bBandas.jpg" name="i" width="450" height="400" id="i" /> </div>
            
          <div class="fundo">
              <p> <strong>Bandas</strong></p>
              <p> <small>Kyodai Land com o melhor do J-Music, B4 a melhor banda de Uberaba e regi&atilde;o cantando pop rock, e Theoria cover de super bandas como SOAD, Slipknot entre outros</small></p>
            </div>
            </a>
          </li>
          
<li> <a href="?go=Atracoes&acao=Atracoes%2FPalestraDubladores">
            <div id="img"> <img src="Fotos/bCampeonatodeGames.jpg" name="i" width="450" height="400" id="i" /> </div>
            
          <div class="fundo">
              <p> <strong>Campeonato de Games</strong></p>
              <p>Preparados para esse desafio &eacute;pico? Naruto Ninja Storm 3 Full Burst, Injustice, Dragon Ball Budokai Tenkaishi 3, Super Smash Bross e &eacute; PES 2014 em clima de copa!</p>
            </div>
            </a>
          </li>
          
<li> <a href="?p=Atracoes&acao=Atracoes%2FConcursoCosplay">
            <div id="img"> <img src="Fotos/bConcursodeCosplay.jpg" name="i" width="450" height="400" id="i" /> </div>
            
          <div class="fundo">
              <p> <strong>Concurso de Cosplay</strong></p>
              <p>S&oacute; os verdadeiros apaixonados entendem a arte de fazer um cosplay, e aqui o artista &eacute; voc&ecirc;! Mostre tudo o que voc&ecirc; tem no concurso de cosplay e ganhe pr&ecirc;mios</p>
            </div>
            </a>
          </li>
          
<li> <a href="?go=Atracoes&acao=Atracoes%2FPalestraDubladores">
            <div id="img"> <img src="Fotos/bSalasSematicas.jpg" name="i" width="450" height="400" id="i" /> </div>
            
          <div class="fundo">
              <p> <strong>Salas Tem&aacute;ticas</strong></p>
              <p>Aqui voc&ecirc; pode soltar sua voz, desenhar, aprender japon&ecirc;s, origami ou at&eacute; mesmo assistir um bom anime</p>
            </div>
            </a>
          </li>
          
<li> <a href="?p=Atracoes&acao=Atracoes%2FZombiePark">
            <div id="img"> <img src="Fotos/bzombiepark.jpg" name="i" width="450" height="400" id="i" /> </div>
            
          <div class="fundo">
              <p> <strong>Zumbie Park</strong></p>
              <p>Um novo desafio mais assustador, mais dif&iacute;cil, onde voc&ecirc; estar&aacute; cara a cara com o terror e sua &uacute;nica op&ccedil;&atilde;o &eacute; sobreviver!</p>
            </div>
            </a>
          </li>                                                  
        </ul>
  </div>