<h1><strong>INGRESSOS</strong></h1>
<p>&nbsp;</p>
<p>
				<strong>Informa&ccedil;&otilde;es e valores</strong></p>
			<p>
				Ingressos Antecipado: R$15,00<br />
				Ingressos lote Normal: R$ 20,00</p>
			<p>
				<span style="background-color: rgb(255, 255, 0);">Observa&ccedil;&atilde;o: Os ingressos ser&atilde;o vendidos nos pontos de venda a partir de 24/04/2014.</span></p>
			<p>&nbsp;
				</p>
			<p>
				<strong>Pontos de venda dos ingressos:</strong></p>
			<p>
				<strong>NANDA FASHION</strong>				</p>
			<p>
				Pra&ccedil;a Rui Barbosa, Elvira Shopping - Loja 21<br />
				Centro &ndash; Uberaba/MG<br />
				Telefone: (34) 3312-0238</p>
			<p>&nbsp;
				</p>
			<p>
				<strong><span style="color:red;">[ESGOTADO] </span>YOGOBERRY</strong></p>
			<p>
				Avenida Santa Beatriz da Silva, Shopping Center Uberaba, 1501<br />
				S&atilde;o Benedito &ndash; Uberaba/MG<br />
				Telefone: (34) 3334-5500				</p>
<p>&nbsp;</p>

<p style="text-align: justify;"><strong>
			CAMISA 12</strong></p>
		<p style="text-align: justify;">
			Avenida Santa Beatriz da Silva, Shopping Center Uberaba, 1501 <br />
		  S&atilde;o Benedito &ndash; Uberaba/MG <br />
		  Telefone: (34) 3336-7344</p>
<p style="text-align: justify;">&nbsp;</p>
            
			<p>
				<strong>Atendimento Preferencial</strong></p>
			<p>
				Gestantes <br />
				Pessoas com crian&ccedil;as de colo<br />
				Idosos<br />
				Deficientes f&iacute;sicos</p>
			<p>
				<strong>Isen&ccedil;&atilde;o de Pagamento</strong></p>
			<p>
				Crian&ccedil;as de 0 a 5 anos<br />
				Adultos com mais de 60 anos</p>