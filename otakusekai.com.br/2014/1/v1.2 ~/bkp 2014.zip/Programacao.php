<h1><strong>PROGRAMA&Ccedil;&Atilde;O</strong></h1>


<p>&nbsp;</p>
<p style="margin-left:40px;">11:00 - THEORIA</p>
<p style="margin-left:40px;">12:00 - APRESENTAÇÃO DE KUNG-FU</p>
<p style="margin-left:40px;">12:45 - JAPAN GAME SHOW</p>
<p style="margin-left:40px;">13:30 - KYODAI LAND</p>
<p style="margin-left:40px;">14:30 - PALESTRA COM OS DUBLADORES</p>
<p style="margin-left:40px;">16:00 - ANIME QUIZ</p>
<p style="margin-left:40px;">16:45 - CONCURSO DE COSPLAY</p>
<p style="margin-left:40px;">18:30 - BQUATRO</p>
