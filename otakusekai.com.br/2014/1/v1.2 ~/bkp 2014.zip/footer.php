<div class="footer">
    
  <div id="p-a-pv">
    <table width="100%" border="0" align="left">
      <tr>
        <td width="255" align="left"><img src="imagens/normas.png" width="209" height="43" /></td>
        <td width="830" height="200" align="left" valign="top">
        <br clear="all" />        <br clear="all" />
        	<img src="imagens/pontos_de_venda.png" width="152" height="22" />
        <br />
        <br />
        <img src="Fotos/nandafashion.png" width="164" height="106" /> <img src="Fotos/yogoberry.png" width="310" height="84" /></td>
        <td align="right">
			<small><span style="margin-right:55px;"><a href="http://bit.ly/1pl7GvL" target="_blank">&copy; FLSS</a></span><br />
            <span style="font-size:80%;margin-right:30px;">Otaku Sekai - 2014
                </span>
                </small>
            
				
        </td>
      </tr>
    </table>
        	<div class="pokefooter">&nbsp;</div>
  </div>
    
</div>



