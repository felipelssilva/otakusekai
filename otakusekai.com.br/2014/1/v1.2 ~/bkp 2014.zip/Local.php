<h1><strong>LOCAL</strong></h1>


<p>&nbsp;</p>
<p>Casa de Festa Sambur&aacute; – Avenida Santos Dummont, n° 2008 – Bairro Santa Maria – Uberaba – MG </p>
<p><br>
</p>
<a href="Fotos/mapa.jpg" target="_blank">
<p align="center"><img src="Fotos/mapa.jpg" width="600" /><br />
Clique aqui para ampliar a imagem.
 </p></a>
