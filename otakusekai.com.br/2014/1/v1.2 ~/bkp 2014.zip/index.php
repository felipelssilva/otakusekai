 <? /*<img src="imagens/logoOtakuMaior2014.png" onmouseover="this.src='imagens/logoOtakuMaior2014_hover.png'" onmouseout="this.src='imagens/logoOtakuMaior2014.png'" width="400" height="231"/>*/ ?>
 
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>C.A.O.S. - Conven&ccedil;&atilde;o de Animes Otaku Sekai</title>

	<link rel="shortcut icon" href="favicon.ico" />


   
    <meta name="description" content="CAOS - Convencao de Animes Otaku Sekai de Uberaba">
    <meta name="keywords" content="convencao, anime, otaku, desenho">
    
    <link rel="stylesheet" type="text/css" media='all' href="css/styles.css?<?php echo microtime();?>" />

	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" href="css/destaque.css?<?php echo microtime();?>" type="text/css" />
	<script type="text/javascript" src="js/jquery.cycle.all.min.js"></script>
	<script type="text/javascript" src="js/jquery.destaques.js"></script>
    
    <script type="text/javascript">
		$(function() {
			jQuery('#divMenu1').css({ fontSize:"70%", padding:"0 5px 5px 5px" });		
			jQuery('#Subdiv_Atr').click(function() {			
				jQuery('#divMenu1').slideToggle();
				jQuery(this).addClass("Subdiv2");				
			});		
			
		});
		
		$(function() {
			jQuery('#divMenu2').css({ fontSize:"70%", padding:"0 5px 5px 5px" });	
			jQuery('#Subdiv_Atv').click(function() {
				jQuery('#divMenu2').slideToggle();
				jQuery(this).addClass("Subdiv2");			
			});
			
		});	
		
		
    var sourceSwap = function () {
        var $this = $(this);
        var newSource = $this.data('alt-src');
        $this.data('alt-src', $this.attr('src'));
        $this.attr('src', newSource);
    }

    $(function () {
        $('img.BannerCAOS').hover(sourceSwap, sourceSwap);
    });			
	</script>
   
</head>

<body>

        <div id="fb-root"></div>
        <script>(function(d, s, id) {
          var js, fjs = d.getElementsByTagName(s)[0];
          if (d.getElementById(id)) return;
          js = d.createElement(s); js.id = id;
          js.src = "//connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v2.0";
          fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>

<div class="escopo" align="center">

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="265" align="center">
    	<span class="coluna" style="width:260px">
        	<img src="imagens/Pokemon-top.png" width="221" height="183">
        </span>
    </td>
    <td width="250" align="right" bgcolor="#D90000">
      <img src="imagens/LOGO_SAMBURA.png" width="145" height="177"></td>
    <td align="right" bgcolor="#D90000">
                <div style="padding:10px; color:#FFF; text-shadow: 0 1px 0px #000;"><span style="font-size:250%;"><strong>DIA 1&deg; DE JUNHO</strong></span>
                    <br />
                das 10h &agrave;s 19h.
                    <br />
                <strong>Local</strong>
                    <br />
                Casa de Festa Sambur&aacute;
                    <br />
                Avenida Santos Dummont, n&deg; 2008
                    <br />
                Bairro Santa Maria
                    <br />
                Uberaba – MG 
                    <br />
                <strong>Ingresso</strong>
                    <br />
                Antecipado: R$ 15,00.
                    <br />
        Porta: R$20,00.</div>    
    </td>
    <td align="right" bgcolor="#D90000">
        <a href="?">
        <img class="BannerCAOS" data-alt-src="imagens/logoOtakuMenor2014_hover.png" src="imagens/logoOtakuMenor2014.png" width="400" height="231" />
        </a>    
    </td>
  </tr>
</table>

<div class="menu">
        <ul>
            <li><a href="?">In&iacute;cio</a></li>
            <li><a href="?p=Evento#ir">Evento</a></li>
            <li><a href="?p=Programacao#ir">Programa&ccedil;&atilde;o</a></li>
            <li><a href="?p=Local#ir">Local</a></li>
            <li><a href="?p=Ingressos#ir">Ingressos</a></li>
            <li><a href="?p=Caravanas#ir">Caravanas</a></li>
            <li><a href="?p=Contato#ir">Contato</a></li>
            <li><a href="?p=Fotos#ir">Fotos</a></li>            
        </ul>
    </div>

        
		<div class="Pokebola_bola">&nbsp;</div>



  <!-- MENU -->
            <a id="menuv"></a>
            
<div class="menuv">
            
            <ul>
                       
            <li class="Subdiv" id="Subdiv_Atr">Atra&ccedil;&otilde;es</li>
            
         
         <div id="divMenu1">
         
                <li><a href="?p=Atracoes&acao=Atracoes%2FIsabeldeSaeMarcioAraujo#Subdiv_Atr">Palestra com Isabel de S&aacute; e M&aacute;rcio Ara&uacute;jo</a></li>
                <li><a href="?p=Atracoes&acao=Atracoes%2FBandas#Subdiv_Atr">Bandas</a></li>
                <li><a href="?p=Atracoes&acao=Atracoes%2FApresentacaoArtesMarciais#Subdiv_Atr">Apresenta&ccedil;&atilde;o de Artes Marciais</a></li>
                <li><a href="?p=Atracoes&acao=Atracoes%2FConcursoCosplay#Subdiv_Atr">Concurso de Cosplay</a></li>
                <li><a href="?p=Atracoes&acao=Atracoes%2FAnimequiz#Subdiv_Atr">Animequiz</a></li>
                <li><a href="?p=Atracoes&acao=Atracoes%2FJapanGameShow#Subdiv_Atr">Japan Game Show</a></li> 
                <li><a href="?p=Atracoes&acao=Atracoes%2FZombiePark#Subdiv_Atr">Zombie Park</a></li>
                <li><a href="?p=Atracoes&acao=Atracoes%2FCompletePokedex#Subdiv_Atr">Complete a Pokedéx!</a></li> 
				
          </div> 
                
			
                        
            <li class="Subdiv" id="Subdiv_Atv">Atividades</li>
            
        <div id="divMenu2">
        
                <li><a href="?p=Atividades&acao=Atividades%2FSalaNimpo#Subdiv_Atv">Sala Nimpo</a></li>
                <li><a href="?p=Atividades&acao=Atividades%2FMaidCafe#Subdiv_Atv">Maid Caf&eacute;</a></li>
                <li><a href="?p=Atividades&acao=Atividades%2FAnimeoke#Subdiv_Atv">Animeok&ecirc;</a></li>
                <li><a href="?p=Atividades&acao=Atividades%2FTemplodosGames#Subdiv_Atv">Templo dos Games</a></li>
                <li><a href="?p=Atividades&acao=Atividades%2FFanArea#Subdiv_Atv">FanArea</a></li>
                <li><a href="?p=Atividades&acao=Atividades%2FTaverna#Subdiv_Atv">Taverna</a></li>
                <li><a href="?p=Atividades&acao=Atividades%2FBatalhaCampal#Subdiv_Atv">Batalha Campal</a></li>
                <li><a href="?p=Atividades&acao=Atividades%2FJustDance#Subdiv_Atv">Just Dance</a></li>                
                <li><a href="?p=Atividades&acao=Atividades%2FCardGames#Subdiv_Atv">Card Games</a></li>
                <li><a href="?p=Atividades&acao=Atividades%2FExibicaodeAnimes#Subdiv_Atv">Exibi&ccedil;&atilde;o de Animes</a></li>
                <li><a href="?p=Atividades&acao=Atividades%2FCosplayHelp#Subdiv_Atv">Cosplay Help </a></li>
                <li><a href="?p=Atividades&acao=Atividades%2FGuardaVolumes#Subdiv_Atv"> Guarda Volumes</a></li>
                <li><a href="?p=Atividades&acao=Atividades%2FEstandesProdutos#Subdiv_Atv">Estandes de Produtos</a></li> 
                <li><a href="?p=Atividades&acao=Atividades%2FAlimentacao#Subdiv_Atv">Alimenta&ccedil;&atilde;o</a></li>
            </div>
                
            </ul>        
        
            </div>
            
            <!-- MENU -->                      

            
    <div class="conteudo">
    
      <div id="conteudo2">
      
      
    <!-- destaques -->
    
		<? include "blocoDestaque.php" ;?>
            
    <!-- /destaques -->
    
    
             <br clear="all">
            
            	<div class="divisaoConteudo">
                		<a id="ir"></a>
                	<div class="Pokebola_bola"></div>
                </div>
            
             <br clear="all">
             
             
                 
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td valign="top">
                    
      <div>
        <?php
            
            $ir = $_GET['p'];
            $ext = (isset($_GET['ext']));
                if (empty($ext)){ 
                    $ext="php";
                }
                if (empty($ir)){ 
                    $ir = "home.php"; 
                }
                else {
                    $ir .= ".".$ext;
                    }
                if (file_exists($ir)){ 
                    include $ir; 
                }
                else { 
                    include "erropagina.php"; 
                } 	
            ?>
       </div>                    
                    
                    </td>
                    <td width="270" height="1300" align="center" valign="top">
                                <div class="divContLateral" align="center">
                                
                                	<div class="fb-like-box" data-href="https://www.facebook.com/ConvencaoOtakuSekai?fref=ts" data-width="210" data-height="350" data-colorscheme="light" data-show-faces="true" data-header="false" data-stream="false" data-show-border="true"></div>
                                	<br clear="all" />
                                	<br clear="all" />                                    
                                	<br clear="all" />
Apoio<br>
                                    <a href="http://bit.ly/1hKCNIx" target="_blank"><img src="Fotos/logo_FikipiGames.png" width="150" height="150"></a>                                                  
                                    <img src="imagens/210x140-1.jpg" width="210" height="140" />
                                    <img src="imagens/210x140-2.jpg" width="210" height="140" />                       
                                    <img src="imagens/210x140-3.jpg" width="210" height="140" />
                                    <img src="imagens/210x140-4.jpg" width="210" height="140" />
                                    <img src="imagens/210x140-5.jpg" width="210" height="140" />
                                    <img src="imagens/210x140-6.jpg" width="210" height="140" />
                                    <img src="imagens/210x140-7.jpg" width="210" height="140" />                        
                                </div>    
                    </td>
          </tr>
        </table>
      
      </div>
            
    </div>

        <div class="Charizard"><a href="#">&nbsp;</a></div>

	<? include "footer.php"; ?>

</div>           
    
</body>
</html>	