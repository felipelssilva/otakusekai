<h1><strong>COSPLAY HELP</strong></h1>

		<p style="text-align: justify;">&nbsp;
</p>


<p style="text-align: justify;">
			Aqui ser&aacute; uma sala destinada ao auxilio em pequenos imprevistos que podem ocorrer com seu Cosplay. Teremos nesta sala pessoas e equipamentos para os primeiros socorros de Cosplayers como maquiagens, linhas, agulhas entre outros materiais que possam ajudar em seu auxilio.</p>
		<p style="text-align: justify;">
			Montaremos tamb&eacute;m cabines para troca de roupa para aqueles que necessitarem de um lugar mais reservado para colocar ou retirar seu cosplay.</p>
		<p style="text-align: justify;">
			Aten&ccedil;&atilde;o: A sala de HELP COSPLAY estar&aacute; aberta at&eacute; 30 minutos antes da apresenta&ccedil;&atilde;o dos Cosplayers, pois neste tempo os Cosplayers devem estar prontos pra se apresentarem no palco, e retornar&aacute; ap&oacute;s as apresenta&ccedil;&otilde;es.</p>
		<p style="text-align: justify;">
			Durante a apresenta&ccedil;&atilde;o dos COSPLAYERS a equipe de help cosplay estar&aacute; perto do palco com todos os equipamentos necess&aacute;rios para precaver qualquer ocasi&atilde;o inesperada que pode ocorrer antes da apresenta&ccedil;&atilde;o dos COSPLAYERS.</p>