<h1>Maid Caf&eacute;</h1>

<p>&nbsp;</p>

<div align="center">
	<img src="Fotos/maid.jpg" width="576" height="421" />
</div>

<p>O Maid est&aacute; com o grupo Chaleira do Drag&atilde;o. Chaleira do Drag&atilde;o &eacute; um lugar para satisfazer as necessidades b&aacute;sicas de todo nerd: cafe&iacute;na, comida, e nerdice.<br />
<br />
Com receitas inspiradas nos filmes, livros e universos que todos amam, do ch&aacute; com biscoitos t&iacute;pico de uma confort&aacute;vel toca de hobbit at&eacute; um Darth Vader de chocolate com pimenta, essa &eacute; a Cafeteria para a Todos Esquentar.. Algumas vezes com todos universos misturados e em outras focando num &uacute;nico tema nerd, mas sempre trazendo comidas deliciosas!!</p>
<p><a href="https://www.facebook.com/ChaleiradoDragao" target="_blank">https://www.facebook.com/ChaleiradoDragao</a></p>
