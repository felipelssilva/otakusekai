<h1><strong>ESTANDES DE PRODUTOS</strong></h1>

		<p style="text-align: justify;">&nbsp;
</p>
<p style="text-align: justify;">
			&Eacute; claro que n&atilde;o poderiam faltar as lojas para todos os otakus reporem o estoque no seu guarda-roupas n&eacute;? Vamos apresentar algumas das lojas confirmadas:</p>
<p style="text-align: justify;">&nbsp;</p>
		<p style="text-align: justify; margin-left: 80px;">
		- Otaku Store</p>
		<p style="text-align: justify; margin-left: 80px;">
			- QQCosplay		</p>
		<p style="text-align: justify; margin-left: 80px;">
			- Pixelland</p>
		<p style="text-align: justify; margin-left: 80px;">
			- Animeage</p>
		<p style="text-align: justify; margin-left: 80px;">
			- StreetAnimes</p>
		<p style="text-align: justify; margin-left: 80px;">
			- Ichiban</p>
		<p style="text-align: justify;">&nbsp;</p>

        <table border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td align="center"><a href="https://www.facebook.com/animeage.brasil" target="_blank"><img src="Fotos/animeage.jpg" width="196" height="196" /></a></td>
            <td align="center"><a href="https://www.facebook.com/evocc.acessorios" target="_blank"><img src="Fotos/EVOCC.png" width="196" height="116" /></a></td>
            <td align="center"><a href="https://www.facebook.com/IchibanProdutos" target="_blank"><img src="Fotos/ICHIBAN.png" width="255" height="94" /></a></td>
          </tr>
          <tr>
            <td align="center"><a href="https://www.facebook.com/OtakuStoreUberaba" target="_blank"><img src="Fotos/OtakuStore.JPG" width="249" height="52" /></a></td>
            <td align="center"><a href="https://www.facebook.com/pixelland.com.br" target="_blank"><img src="Fotos/Pixelland.jpg" width="204" height="218" /></a></td>
            <td align="center"><a href="http://streetgamesanime.loja2.com.br/page/30076-STREET-ANIMES" target="_blank"><img src="Fotos/STREETANIMES.jpg" width="248" height="62" /></a></td>
          </tr>
</table>
<p style="text-align: justify;">
Mais atualiza&ccedil;&otilde;es em breve.</p>