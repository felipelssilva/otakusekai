<h1>Por&atilde;o Nerd</h1>

		<p style="text-align: justify;">&nbsp;
			</p>

<div align="center">
	<img src="Fotos/porao_nerd.jpg" width="364" height="213" />
</div>


<p style="text-align: justify;">
			Reservamos esse espa&ccedil;o especial da conven&ccedil;&atilde;o para remontar os cen&aacute;rios &eacute;picos de Star Wars ou Lord of Rings, para os amantes do HQ, geeks, treckers e tudo o que conseguimos reunir do universo mais rico que existe: o Universo Nerd.</p>