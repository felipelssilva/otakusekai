<h1><strong>Animeok&ecirc;</strong></h1>

<p>&nbsp;</p>


<div align="center">
	<img src="Fotos/animeoke.jpg" width="426" height="320" />
</div>

<p>&nbsp;</p>

<p style="text-align: justify;">
			Voc&ecirc; gosta de cantar as suas aberturas de anime preferidas? Ent&atilde;o venha soltar a voz no campeonato de Animeoke da C.A.O.S.!</p>
		<p style="text-align: justify;">
			<strong>Regras</strong></p>
		<p style="text-align: justify;">
			<strong>1 - Inscri&ccedil;&otilde;es:</strong></p>
		<p style="text-align: justify; margin-left: 40px;">
			<strong>1.1 - </strong>A inscri&ccedil;&atilde;o ser&aacute; gratuita,dever&aacute; ser feita na sala de animeok&ecirc;.<br />
			<strong>1.2 - </strong>As inscri&ccedil;&otilde;es come&ccedil;am 10h00min e podem ser feitas at&eacute; as 14h00min.<br />
			<strong>1.3 - </strong>O Participante dever&aacute; escolher duas m&uacute;sicas (animes e tokusatsus em japon&ecirc;s),uma para ser cantada na sala e outra se o mesmo passar para a final no palco.<br />
<strong>1.4 -</strong> O competidor dever&aacute; preencher este pedido colocando nos respectivos espa&ccedil;os o seu NOME, o nome da M&Uacute;SICA a interpretar.</p>
		<p style="text-align: justify;">
			<strong>2 - Disposi&ccedil;&otilde;es Gerais</strong></p>
		<p style="text-align: justify; margin-left: 40px;">
			<strong>2.1 - </strong>Se chegar sua vez e voc&ecirc; n&atilde;o estiver, ou colocar musica na sala de karaok&ecirc; e n&atilde;o cantar, voc&ecirc; ser&eacute; eliminado.<br />
			<strong>2.2 - </strong>Cada Participante deve ter as musicas decoradas para a competi&ccedil;&atilde;o.<br />
			<strong>2.3 - </strong>Dever&atilde;o manter o respeito entre os participantes.<br />
			<strong>2.4 - </strong>A ger&ecirc;ncia do espa&ccedil;o e o animador podem impedir a participa&ccedil;&atilde;o dos competidores que apresentarem comportamento inadequado.<br />
			<strong>2.5 - </strong>Qualquer conhecido de algum participante na plat&eacute;ia que n&atilde;o permane&ccedil;a em sil&ecirc;ncio poder&aacute; causar a desclassifica&ccedil;&atilde;o daquele participante.<br />
			<strong>2.6 - </strong>Em caso de dano aos objetos do karaok&ecirc; eles dever&atilde;o ser pagos por quem os causou.<br />
			<strong>2.4 - </strong>Haver&aacute; a presen&ccedil;a de 3 jurados.<br />
<strong>2.5 - </strong>Os crit&eacute;rios de avalia&ccedil;&atilde;o ser&atilde;o:</p>
		<p style="text-align: justify; margin-left: 80px;">
			- Postura<br />
			- Pronuncia<br />
			- Presen&ccedil;a de palco<br />
- Afina&ccedil;&atilde;o</p>
		<p style="text-align: justify;">
			<strong>3 - Final e premia&ccedil;&atilde;o</strong></p>
		<p style="text-align: justify; margin-left: 40px;">
			<strong>3.1 - </strong>A Final acontecer&aacute; entre tr&ecirc;s participantes no palco<br />
			<strong>3.2 - </strong>Os Participantes dever&atilde;o estar 15 minutos antes da apresenta&ccedil;&atilde;o no palco.<br />
			<strong>3.3 - </strong>No Palco tamb&eacute;m contaremos com o j&uacute;ri popular<br />
<strong>3.4 - </strong>A Premia&ccedil;&atilde;o ser&aacute; revelada em breve.</p>
		<p style="text-align: justify;">
			<strong>4 - Demais disposi&ccedil;&otilde;es:</strong></p>
		<p style="text-align: justify; margin-left: 40px;">
			<strong>4.1 - </strong>Desde j&aacute;, todos os participantes autorizam a publica&ccedil;&atilde;o e divulga&ccedil;&atilde;o de sua imagem pela organiza&ccedil;&atilde;o da C.A.O.S. em qualquer m&iacute;dia vinculada ao evento.<br />
			<strong>4.2 - </strong>O preenchimento e entrega da ficha de inscri&ccedil;&atilde;o atestam que o inscrito est&aacute; ciente e de acordo com as regras aqui dispostas.<br />
<strong>4.3 - </strong>Os casos omissos ser&atilde;o resolvidos pela organiza&ccedil;&atilde;o da C.A.O.S, cabendo a eles decis&atilde;o incontest&aacute;vel.</p>