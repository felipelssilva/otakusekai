<h1><strong>Sala Nimp&ocirc;</strong></h1>

		<p style="text-align: justify;">&nbsp;
</p>

<div align="center">
	<img src="Fotos/nimpo.jpg" width="500" height="328" />
</div>

<p style="text-align: justify;">
			A Sala Nimp&ocirc; traz um pouco do oriente para dentro da C.A.O.S. com aulas de japon&ecirc;s, oficinas de origamis, um espa&ccedil;o onde voc&ecirc; vai saber tudo sobre o K-pop e J-pop e tamb&eacute;m a realiza&ccedil;&atilde;o do Matsuri, um lindo festival japon&ecirc;s. Tudo isso e muito mais para voc&ecirc; se sentir na terra do sol nascente!</p>
<p style="text-align: justify;">&nbsp;</p>
<p style="text-align: justify;">OFICINA DE JAPONÊS DAS 10H00MIN AS 13H00MIN!</p>
