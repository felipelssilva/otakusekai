<h1>TAVERNA</h1>

		<p style="text-align: justify;">&nbsp;
</p>

<div align="center">
	<img src="Fotos/taverna.jpg" width="448" height="252" />
</div>


<p style="text-align: justify;">
			Nesta taverna, teremos palestras e ensinaremos um pouco mais sobre o RPG, al&eacute;m de din&acirc;micas em grupo, os populares jogos de tabuleiros!</p>
		<p style="text-align: justify;">
			<strong><em>O Role-playing game</em></strong> popularmente conhecido como&nbsp;jogo de interpreta&ccedil;&atilde;o de personagens,&nbsp;&eacute; um jogo&nbsp;em que um grupo jogadores assumem os pap&eacute;is de personagens e criam narrativas colaborativamente seguindo regras pr&eacute;-determinadas de acordo com o mestre, que coordena a dire&ccedil;&atilde;o da hist&oacute;ria.</p>
