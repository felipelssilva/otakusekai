<h1><strong>Just Dance</strong></h1>

<p>&nbsp;</p>


<div align="center">
	<img src="Fotos/just-dance.jpg" width="465" height="251" />
</div>

<p>&nbsp;</p>


<p style="text-align: justify;">
			Mostre todas as suas habilidades de dan&ccedil;a no Just Dance. O jogo do Wii que virou uma febre no mundo todo &eacute; baseado em imitar os movimentos de dan&ccedil;a usando o controle sensorial. Se voc&ecirc; &eacute; fera ou vai pagar mico, n&atilde;o importa, o importante &eacute; se divertir!</p>
		<p style="text-align: justify;">
			<strong>Formato do campeonato</strong></p>
		<p style="text-align: justify; margin-left: 80px;">
			<strong>1. </strong>&nbsp;O Torneio ocorrer&aacute; &agrave;s 16:00;</p>
		<p style="text-align: justify; margin-left: 80px;">
			<strong>2. </strong>&nbsp;Participa&ccedil;&atilde;o individual;</p>
		<p style="text-align: justify; margin-left: 80px;">
			<strong>3.</strong> &nbsp;M&iacute;nimo de 8 participantes;</p>
		<p style="text-align: justify; margin-left: 80px;">
			<strong>4.</strong> &nbsp;A sele&ccedil;&atilde;o do vencedor ser&aacute; por chave eliminat&oacute;ria e cada partida ser&aacute; decidida pela maior pontua&ccedil;&atilde;o;</p>
		<p style="text-align: justify; margin-left: 80px;">
			<strong>5. </strong>&nbsp;Dois participantes por dan&ccedil;a;</p>
		<p style="text-align: justify; margin-left: 80px;">
			<strong>6.</strong> &nbsp;As dan&ccedil;as ser&atilde;o escolhidas no modo aleat&oacute;rio;</p>
		<p style="text-align: justify; margin-left: 80px;">
			<strong>7.</strong> Cada jogador fica respons&aacute;vel pelo seu pr&oacute;prio controle (compat&iacute;vel com nintendo wii), em caso de n&atilde;o o ter, a organiza&ccedil;&atilde;o disponibilizar&aacute; um da mesma e o participante n&atilde;o ter&aacute; direito a reclama&ccedil;&otilde;es sobre o mesmo;</p>
		<p style="text-align: justify; margin-left: 80px;">
			<strong>8.</strong> &nbsp;As inscri&ccedil;&otilde;es ser&atilde;o gratuitas e estar&atilde;o ocorrendo na C.A.O.S. a partir das 10:00.</p>