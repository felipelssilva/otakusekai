<h1><strong>Exibi&ccedil;&atilde;o de Animes</strong></h1>

		<p style="text-align: justify;">&nbsp;
</p>

<div align="center">
	<img src="Fotos/cineanime.jpg" width="255" height="260" />
</div>



		<p style="text-align: justify;">
			Na sala de exibi&ccedil;&atilde;o de animes, teremos filmes &eacute;picos no Cine Anime, OVA&rsquo;s e AMV&rsquo;s. Envie voc&ecirc; tamb&eacute;m o seu AMV para o e-mail <a href="mailto:animeotakusekai@hotmail.com" target="_blank">animeotakusekai@hotmail.com</a>, os melhores AMVs ser&atilde;o exibidos na sala!&nbsp;</p>
		<p style="text-align: justify;">&nbsp;
</p>
		<p style="text-align: justify;">
Em breve programa&ccedil;&atilde;o!</p>
<p style="text-align: justify;">&nbsp;
</p>
