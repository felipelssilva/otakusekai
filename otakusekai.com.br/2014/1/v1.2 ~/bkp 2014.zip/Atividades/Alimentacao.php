<h1>ALIMENTA&Ccedil;&Atilde;O</h1>

		<p style="text-align: justify;">&nbsp;
</p>


<p style="text-align: justify;">
			A nossa pra&ccedil;a de com conta com as melhores especiarias asi&aacute;ticas de Uberaba e regi&atilde;o. Mas pra quem prefere o b&aacute;sico do cotidiano, teremos tamb&eacute;m nossa salgadaria!</p>
		<p style="text-align: justify;">
			- Itadakimasu</p>
		<p style="text-align: justify;">
			&nbsp;</p>
		<p style="text-align: justify;">
			<strong>Mais atualiza&ccedil;&otilde;es em breve.</strong></p>
